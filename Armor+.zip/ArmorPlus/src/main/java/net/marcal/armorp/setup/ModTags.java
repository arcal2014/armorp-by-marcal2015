package net.marcal.armorp.setup;

import net.minecraft.block.Block;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ITag;

public class ModTags {
    public static final class Blocks {
        public static final ITag.INamedTag<Block> ORES_LEAD =

        private static final ITag.INamedTag<Block> forge(String path) {
            return BlockTags.;
        }
    }

    public static final class Items
}
